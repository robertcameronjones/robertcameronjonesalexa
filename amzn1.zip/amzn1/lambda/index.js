/* eslint-disable no-use-before-define */
/* eslint-disable global-require */

const Alexa = require('ask-sdk-core');
const axios = require('axios');
var outputSpeech = 'This is the original default message.';

const GetRemoteDataHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest'
      || (handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'GetRemoteDataIntent');
  },
  async handle(handlerInput) {
   //handle(handlerInput) {     
      


const sendGetRequest = async () => {
    var speechText;
    try {
        //GPSi API
        const resp = await axios.get('https://secure.guidepointsystems.com/api2/vehicle/details-by-vin?token=3eb68f4f4d058df8b39cf330491f50d8&vin=1C4RJFAG0MC771727');
        console.log(resp.data.vin);
        speechText = "Your "; speechText += resp.data.year; speechText += resp.data.make; speechText += resp.data.model;
        speechText += 'has' ; speechText += resp.data.fuel; speechText += ' percent fuel.  ';
        speechText += 'It has'; speechText += resp.data.miles; speechText += 'miles on the odometer.  ';
        let IGN = resp.data.unit.recent_unit_data.ignition_state;
        if(IGN===1){
            speechText += 'Your Ignition is ON.  ';
          } else{
            speechText += "Your Ignition is OFF. ";
        }
        const latitude = resp.data.unit.recent_unit_data.latitude;
        const longitude =  resp.data.unit.recent_unit_data.longitude;
        //speechText += ' Your latitude is'; speechText += latitude;
        //speechText += '. Your longitude is '; speechText +=longitude;
        // Reverse Geocode API
        const resp2 = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyCDixWg8ThyMNQZynxlOomHsDD5fqsMlo0`);
        console.log(resp2.data);
        speechText += 'Your vehicle is at ';  speechText += resp2.data.results[0].formatted_address;
        //CAR MD Service API
        //const resp3 = await axios.get('https://secure.guidepointsystems.com/api2/vehicle/details-by-vin?token=3eb68f4f4d058df8b39cf330491f50d8&vin=1C4RJFAG0MC771727');
        
        const vin = '1C4RJFAG0KC771727';
        
        
        const resp3 = await axios.get(`https://api.carmd.com/v3.0/maint?vin=${vin}&mileage=4000`, {
        headers: {
                  'Authorization' : 'Basic Y2JlYjljNWUtYWUzMy00NDk0LWFhOTQtNTAyYTBiYmIxMGYz',
                  'partner-token' : '28bcbaf7458b473382eb5e253d8f5121'
                  }
       })
       console.log('CAR MD data====>');
       console.log(resp3.data);
       
       
         let elements = resp3.data.data.length;
         console.log(elements);
         
         speechText += '.  Your next service is at ';
         speechText += resp3.data.data[0].due_mileage;
         speechText += ' miles.  Your service will include ';
         
         for (let i=0;i<elements;i++){
             let serviceElement = resp3.data.data[i].desc;
             if(serviceElement.search('Inspect')!==0){
             speechText += resp3.data.data[i].desc;
             speechText += ' and ';
             }
          }
      speechText += 'various vehicle system inspections';
       
      //console.log(speechText);
      let finalSpeechText = speechText.replace(/&/g, 'and');
      console.log(finalSpeechText);      
        
        return(finalSpeechText);           
        
    } catch (err) {
        // Handle Error Here
        console.error(err);
    }
    finally {
     console.log('finally');
    }
};

outputSpeech = await sendGetRequest();


    console.log('***ready to speak****');
    return handlerInput.responseBuilder
      .speak(outputSpeech)
      .getResponse();
  },
};



const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speechText = 'You can introduce yourself by telling me your name';

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .getResponse();
  },
};

const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speechText = 'Goodbye!';

    return handlerInput.responseBuilder
      .speak(speechText)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, I can\'t understand the command. Please say again.')
      .reprompt('Sorry, I can\'t understand the command. Please say again.')
      .getResponse();
  },
};

const getRemoteData = (url) => new Promise((resolve, reject) => {
  const client = url.startsWith('https') ? require('https') : require('http');
  const request = client.get(url, (response) => {
    if (response.statusCode < 200 || response.statusCode > 299) {
      reject(new Error(`Failed with status code: ${response.statusCode}`));
    }
    const body = [];
    response.on('data', (chunk) => body.push(chunk));
    response.on('end', () => resolve(body.join('')));
  });
  request.on('error', (err) => reject(err));
});

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    GetRemoteDataHandler,
    HelpIntentHandler,
    CancelAndStopIntentHandler,
    SessionEndedRequestHandler,
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();


    
/* axios.get('https://guidepointsystems.com/api2/distributor/details-by-vin?distributor_token=c4809e86766e99c0ec57f79c6c0c1b46&vin=3N1AB7AP2EY322903')


//axios.get('https://www.juniordeveloper.com')
.then(result => {
    console.log("logging result *****  ")
    console.log(result);
    console.log("  *****");
    //let outputSpeech = JSON.parse(result).esn;
    
})
.catch(error=>{
    console.log(error);
})
.finally(() => {
  console.log("***FINALLY***");
  outputSpeech = 'Speech Override';
  block = false;
 
  
  //let outputSpeech = 'Override Message';
})   
*/
    
    
    //const api_url = 'https://guidepointsystems.com/api2/distributor/details-by-vin?distributor_token=c4809e86766e99c0ec57f79c6c0c1b46&vin=3N1AB7AP2EY322903';
   // const response = await fetch(api_url);
 /*   
       await getRemoteData('http://api.open-notify.org/astros.json')
      .then((response) => {
        const data = JSON.parse(response);
        outputSpeech = `There are currently ${data.people.length} astronauts in space. `;
        for (let i = 0; i < data.people.length; i += 1) {
          if (i === 0) {
            // first record
            outputSpeech = `${outputSpeech}Their names are: ${data.people[i].name}, `;
          } else if (i === data.people.length - 1) {
            // last record
            outputSpeech = `${outputSpeech}and ${data.people[i].name}.`;
          } else {
            // middle record(s)
            outputSpeech = `${outputSpeech + data.people[i].name}, `;
          }
        }
      })
      .catch((err) => {
        console.log(`ERROR: ${err.message}`);
        // set an optional error message here
        // outputSpeech = err.message;
      });
      
      */
